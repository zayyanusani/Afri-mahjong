# Store listing drafts: Africa Mahjong

Fill in or adjust anything in [brackets]. Character limits are noted; counts were checked when this file was generated.

## Names and short text
- **App name (Google Play and App Store, max 30):** Africa Mahjong
- **iOS subtitle (max 30):** African mahjong solitaire
- **Google Play short description (max 80):** African-themed mahjong solitaire with 5,000 levels and daily rewards.
- **iOS promotional text (max 170):** 5,000 levels across 50 African worlds. New twists, daily rewards and a live daily league. Match tiles, beat the clock, climb the board.
- **iOS keywords (max 100, comma separated):** mahjong,solitaire,tile,match,puzzle,africa,brain,relaxing,offline,board game,daily
- **Category:** Games > Puzzle (secondary on iOS: Board)

## Full description (both stores, max 4000)
Travel across Africa one tile at a time.

Africa Mahjong is a relaxing mahjong solitaire game with an African spirit. Match pairs of free tiles to clear the board, from the golden Serengeti to the Nile Delta, the Sahara, the rainforest and beyond.

5,000 LEVELS IN 50 WORLDS
Journey through worlds inspired by Africa's landscapes, from Kilimanjaro and Victoria Falls to Timbuktu and Great Zimbabwe. Boards start small and gentle, then grow into bigger, more challenging layouts.

BOARDS THAT KEEP CHANGING
- Fog hides locked tiles until they come free.
- Waves drop new tiles onto the board as you match.
- Rush gives you a countdown, with leftover seconds as bonus points.
- Sealed tiles unlock only after you make enough matches.
- Boss levels combine twists for a bigger challenge.

EVERY DEAL CAN BE SOLVED
Boards are generated so there is always a way through, and the game reshuffles for you if you get stuck.

BOOSTERS WHEN YOU NEED THEM
Hint, Shuffle and Undo help you out of tight spots. Earn more by clearing boards and completing daily tasks.

COLLECT AND PERSONALIZE
Earn coins to unlock the Adinkra tile set, symbols from the Akan people, or switch back to the animal tiles.

WEEKLY LEAGUES AND DAILY REWARDS
Complete daily tasks, build a login streak for bigger rewards, and climb from Bronze to Epic in weekly leagues: the top 5 of each 30-player group move up, so keep playing to stay ahead.

BEAUTIFUL AND SMOOTH
Warm colors, vector tile art, gentle music and satisfying animations. Large, easy-to-read tiles make it comfortable for all ages.

NO ADS. NO ACCOUNTS. Your progress stays on your device. The league uses only a random player ID, a name you choose and your score. See our privacy policy for details.

## What's new (first release)
First release: 5,000 levels, board twists, daily league, daily rewards and two tile sets.

## Content rating (answer the questionnaires yourself; these are the facts to base them on)
- No violence, blood, gambling, sexual content, profanity or user-to-user chat.
- Player names are visible to other players on the leaderboard (a "user-generated content" question may apply; names are limited to 16 letters, numbers, spaces, underscores and hyphens).
- No real-money purchases and no ads in this version. The shop uses coins earned by playing.
- Expected result: Everyone (Google Play) and 4+ (App Store). Confirm in each console.

## Data safety (Google Play) and App Privacy (Apple): draft answers
Confirm against the current console wording before submitting.
- **Data collected:** a random player ID, the player name the user chooses, and in-app activity (daily best score, level reached, weekly league tier and points). IP address is processed for rate limiting.
- **Purpose:** app functionality (leaderboard) and fraud prevention/security. Not used for advertising or analytics.
- **Shared with third parties:** none for their own purposes. Cloudflare acts as the hosting/processing provider.
- **Data encrypted in transit:** yes (HTTPS).
- **Deletion:** users can delete online data in Settings → Delete online data. Daily scores are removed automatically after 90 days.
- **Tracking:** none. If you later add ads, analytics or purchases, update these answers and the privacy policy first.

## Assets checklist
- App icon 512 x 512 (Play) and 1024 x 1024 (App Store): replace the placeholder in `assets/` with final artwork.
- Feature graphic 1024 x 500 (Play).
- 4 to 8 phone screenshots: home screen, a Savannah board, Fog level, Waves level, Rush level, win screen with podium, journey map, shop.
- Privacy policy URL: https://[YOUR-SITE]/privacy.html
- Support email: [CONTACT EMAIL]
