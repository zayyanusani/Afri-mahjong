// Cloudflare Pages Function: /api/league
// GET  -> { day, top: [{ name, score, lvl }] }   today's top 20 (UTC day)
// POST -> { ok, score, rank, top, weekly }        body: { token, pid, name, actions, timeUsed }
// The score is never taken from the client: the server replays the move log on the seeded board
// (src/core.js) and computes it. Anything illegal is rejected.
import { readToken, seedFor } from "../../src/server/auth.js";
import { verifyRun } from "../../src/server/replay.js";
import { levelSpec, MAX_LEVEL } from "../../src/levels.js";
import { addPoints, standing } from "../../src/server/league.js";

const CORS = { "access-control-allow-origin": "*", "access-control-allow-methods": "GET,POST,OPTIONS", "access-control-allow-headers": "content-type" };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS } });
const dayKey = () => new Date().toISOString().slice(0, 10);

export const onRequestOptions = () => new Response(null, { status: 204, headers: CORS });

export async function onRequestGet({ env }) {
  const day = dayKey();
  const r = await env.DB.prepare("SELECT name, score, lvl FROM scores WHERE day = ?1 ORDER BY score DESC, updated ASC LIMIT 20").bind(day).all();
  return json({ day, top: r.results });
}

export async function onRequestPost({ request, env }) {
  if (!env.LEAGUE_SECRET) return json({ error: "server not configured" }, 500);
  let b;
  try { b = await request.json(); } catch { return json({ error: "bad json" }, 400); }

  const tok = await readToken(env.LEAGUE_SECRET, b.token);
  if (!tok || tok.pid !== b.pid) return json({ error: "invalid token" }, 403);
  if (!(tok.lvl >= 1 && tok.lvl <= MAX_LEVEL)) return json({ error: "invalid level" }, 400);
  const run = await env.DB.prepare("SELECT used FROM runs WHERE nonce = ?1 AND pid = ?2").bind(tok.nonce, tok.pid).first();
  if (!run) return json({ error: "unknown run" }, 403);
  if (run.used) return json({ error: "run already submitted" }, 409);

  let v;
  try {
    v = verifyRun({
      spec: levelSpec(tok.lvl),
      seed: await seedFor(env.LEAGUE_SECRET, tok.nonce),
      actions: b.actions,
      timeUsed: Number(b.timeUsed),
      elapsedMs: Date.now() - tok.started,
    });
  } catch (e) {
    return json({ error: "rejected: " + e.message }, 400);
  }

  // Claim the run only after the replay passes. The claim is atomic, so a run is accepted once.
  const claim = await env.DB.prepare("UPDATE runs SET used = 1 WHERE nonce = ?1 AND used = 0").bind(tok.nonce).run();
  if (claim.meta.changes !== 1) return json({ error: "run already submitted" }, 409);

  const score = v.score;
  const name = String(b.name || "Player").replace(/[^\p{L}\p{N} _-]/gu, "").trim().slice(0, 16) || "Player";
  const day = dayKey();
  await env.DB.prepare(
    "INSERT INTO scores (day, pid, name, score, lvl, updated) VALUES (?1, ?2, ?3, ?4, ?5, ?6) " +
    "ON CONFLICT(day, pid) DO UPDATE SET score = MAX(score, excluded.score), name = excluded.name, lvl = excluded.lvl, updated = excluded.updated"
  ).bind(day, tok.pid, name, score, tok.lvl, Date.now()).run();

  const mine = await env.DB.prepare("SELECT score FROM scores WHERE day = ?1 AND pid = ?2").bind(day, tok.pid).first();
  const rankRow = await env.DB.prepare("SELECT COUNT(*) + 1 AS rank FROM scores WHERE day = ?1 AND score > ?2").bind(day, mine.score).first();
  const top = await env.DB.prepare("SELECT name, score, lvl FROM scores WHERE day = ?1 ORDER BY score DESC, updated ASC LIMIT 3").bind(day).all();

  await addPoints(env, tok.pid, name, score);
  const w = await standing(env, tok.pid, name);
  return json({ ok: true, score, rank: rankRow.rank, top: top.results, weekly: { tierName: w.tierName, rank: w.rank, size: w.size } });
}
