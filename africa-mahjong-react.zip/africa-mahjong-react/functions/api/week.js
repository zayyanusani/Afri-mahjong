// GET /api/week?pid=...  -> this week's group standings for the player (joins them to a group if needed).
import { validPid } from "../../src/server/auth.js";
import { standing } from "../../src/server/league.js";

const CORS = { "access-control-allow-origin": "*", "access-control-allow-methods": "GET,OPTIONS", "access-control-allow-headers": "content-type" };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS } });

export const onRequestOptions = () => new Response(null, { status: 204, headers: CORS });

export async function onRequestGet({ request, env }) {
  const pid = new URL(request.url).searchParams.get("pid");
  if (!validPid(pid)) return json({ error: "invalid" }, 400);
  return json(await standing(env, pid, "Player"));
}
