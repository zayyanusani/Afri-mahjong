// POST /api/run  body { pid, lvl } -> { token, seed }. Called when a level starts.
// The seed is derived on the server from the signed token, so the client can't choose or predict it.
import { makeToken, validPid, seedFor } from "../../src/server/auth.js";
import { MAX_LEVEL } from "../../src/levels.js";

const CORS = { "access-control-allow-origin": "*", "access-control-allow-methods": "POST,OPTIONS", "access-control-allow-headers": "content-type" };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS } });

export const onRequestOptions = () => new Response(null, { status: 204, headers: CORS });

export async function onRequestPost({ request, env }) {
  if (!env.LEAGUE_SECRET) return json({ error: "server not configured" }, 500);
  let b;
  try { b = await request.json(); } catch { return json({ error: "bad json" }, 400); }
  const lvl = Math.floor(Number(b.lvl));
  if (!validPid(b.pid) || !(lvl >= 1 && lvl <= MAX_LEVEL)) return json({ error: "invalid" }, 400);

  const ip = request.headers.get("CF-Connecting-IP") || "unknown", since = Date.now() - 3600e3;
  const byPid = await env.DB.prepare("SELECT COUNT(*) AS n FROM runs WHERE pid = ?1 AND started > ?2").bind(b.pid, since).first();
  const byIp = await env.DB.prepare("SELECT COUNT(*) AS n FROM runs WHERE ip = ?1 AND started > ?2").bind(ip, since).first();
  if (byPid.n >= 40 || byIp.n >= 150) return json({ error: "too many runs, try later" }, 429);

  const t = await makeToken(env.LEAGUE_SECRET, b.pid, lvl);
  await env.DB.prepare("INSERT INTO runs (nonce, pid, ip, started, used) VALUES (?1, ?2, ?3, ?4, 0)").bind(t.nonce, b.pid, ip, t.started).run();
  const seed = await seedFor(env.LEAGUE_SECRET, t.nonce);
  if (Math.random() < 0.02) { // housekeeping: run records after 2 days, scores after 90 days
    await env.DB.prepare("DELETE FROM runs WHERE started < ?1").bind(Date.now() - 2 * 86400e3).run();
    await env.DB.prepare("DELETE FROM scores WHERE day < date('now', '-90 day')").run();
    await env.DB.prepare("DELETE FROM members WHERE week < date('now', '-90 day')").run();
    await env.DB.prepare("DELETE FROM ptier WHERE week < date('now', '-90 day')").run();
  }
  return json({ token: t.token, seed });
}
