// POST /api/claim  body { pid } -> opens last week's league chest once. The claim is atomic, so it can't be repeated.
import { validPid } from "../../src/server/auth.js";
import { rewardFor } from "../../src/server/league.js";

const CORS = { "access-control-allow-origin": "*", "access-control-allow-methods": "POST,OPTIONS", "access-control-allow-headers": "content-type" };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS } });

export const onRequestOptions = () => new Response(null, { status: 204, headers: CORS });

export async function onRequestPost({ request, env }) {
  let b;
  try { b = await request.json(); } catch { return json({ error: "bad json" }, 400); }
  if (!validPid(b.pid)) return json({ error: "invalid" }, 400);
  const p = await env.DB.prepare("SELECT prev_from, prev_to, prev_rank FROM ptier WHERE pid = ?1").bind(b.pid).first();
  if (!p || p.prev_from == null) return json({ error: "nothing to claim" }, 409);
  const c = await env.DB.prepare("UPDATE ptier SET prev_claimed = 1 WHERE pid = ?1 AND prev_claimed = 0").bind(b.pid).run();
  if (c.meta.changes !== 1) return json({ error: "already claimed" }, 409);
  return json({ ok: true, reward: rewardFor(p.prev_from, p.prev_to, p.prev_rank) });
}
