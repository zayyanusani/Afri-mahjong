// POST /api/delete  body { pid }  -> removes that player's leaderboard rows and run records.
import { validPid } from "../../src/server/auth.js";

const CORS = { "access-control-allow-origin": "*", "access-control-allow-methods": "POST,OPTIONS", "access-control-allow-headers": "content-type" };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store", ...CORS } });

export const onRequestOptions = () => new Response(null, { status: 204, headers: CORS });

export async function onRequestPost({ request, env }) {
  let b;
  try { b = await request.json(); } catch { return json({ error: "bad json" }, 400); }
  if (!validPid(b.pid)) return json({ error: "invalid" }, 400);
  const s = await env.DB.prepare("DELETE FROM scores WHERE pid = ?1").bind(b.pid).run();
  const r = await env.DB.prepare("DELETE FROM runs WHERE pid = ?1").bind(b.pid).run();
  const m = await env.DB.prepare("DELETE FROM members WHERE pid = ?1").bind(b.pid).run();
  const t = await env.DB.prepare("DELETE FROM ptier WHERE pid = ?1").bind(b.pid).run();
  return json({ ok: true, deleted: [s, r, m, t].reduce((n, x) => n + (x.meta.changes || 0), 0) });
}
