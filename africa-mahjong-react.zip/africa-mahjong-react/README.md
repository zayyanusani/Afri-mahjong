# Africa Mahjong (React + PWA)

African-themed mahjong solitaire: 7 boards, levels, boosters, daily tasks and rewards, a coin shop with two tile sets, hard mode with sealed tiles, procedural music, and an installable offline app.

## Run
```bash
npm install
npm run dev        # http://localhost:5173
```

## Build and deploy
```bash
npm run build      # outputs dist/
npm run preview    # test the production build (service worker is active here)
```
Upload `dist/` to any static host over **HTTPS** (GitHub Pages, Netlify, Vercel, Cloudflare Pages). The PWA install prompt and offline mode require HTTPS (or localhost).

## Install as an app
- **Android / desktop Chrome and Edge:** open the deployed site, then use Settings → Install, or the browser's install button.
- **iPhone / iPad (Safari):** Share → Add to Home Screen.

## Structure
- `src/data.js` symbols, vector tile art, Adinkra set, board layouts, tasks, backgrounds, music
- `src/engine.js` solvable-deal generator, free-tile rule, audio, particles
- `src/store.js` saved progress (localStorage)
- `src/App.jsx`, `Home.jsx`, `Game.jsx`, `Modals.jsx` UI
- `vite.config.js` PWA manifest and service worker (vite-plugin-pwa)
- `public/icons/` app icons (192, 512, maskable)

## Notes
- Game tiles are mutated in place inside a ref and React re-renders through a tick counter; state that persists (coins, level, boosters) lives in `store.js`.
- Adinkra symbols are simplified drawings. Have Akan designers review them before a public release.

## Android and iOS apps (Capacitor)
Capacitor wraps the built web app in a native shell for the Play Store and App Store.

1. Edit `appId` in `capacitor.config.json` to your own reverse-domain id (for example `com.yourname.africamahjong`). It must be unique and can't change after you publish.
2. `npm install`, then `npm run cap:init` (builds the web app and creates the `android/` and `ios/` projects).
3. Optional app icons and splash screens: put a 1024x1024 `assets/icon-only.png` (the 512 px placeholder is included) and run `npm run cap:assets`.
4. **Android:** `npm run cap:android` opens Android Studio. Use Build → Generate Signed Bundle (AAB) and upload it in the Google Play Console.
5. **iOS:** needs a Mac with Xcode. `npm run cap:ios` opens Xcode. Set your team and signing, then Product → Archive and upload through App Store Connect.
6. After any code change: `npm run cap:sync`.

You need a Google Play developer account for Android and an Apple Developer Program membership for iOS. Check each store's current fees and review rules.

## Deploy to Cloudflare Pages (with the live league)
The daily league leaderboard is a Cloudflare Pages Function (`functions/api/league.js`) backed by a D1 database. The database `africa-mahjong-league` and its `scores` table already exist, and `wrangler.toml` is bound to it.

```bash
npm install
npx wrangler login
npx wrangler pages project create africa-mahjong --production-branch main   # first time only
npm run deploy                     # builds and uploads dist/ plus the API function
```
Your site will be at `https://africa-mahjong.pages.dev`. Test locally with `npm run cf:dev`.

For the Android/iOS apps, build with `VITE_API_BASE=https://africa-mahjong.pages.dev` (see `.env.example`) so the native shell can reach the API.

How the league works: when a player clears a board, the game posts their score. The server keeps each player's best score per UTC day, and returns the top 3 and the player's rank. If the API can't be reached, the game falls back to simulated rivals.

### Required one-time secret
Scores are protected by signed run tokens, so the server needs a secret:
```bash
openssl rand -base64 32                                              # generate a value
npx wrangler pages secret put LEAGUE_SECRET --project-name africa-mahjong
```
Without it, `/api/run` and `/api/league` return "server not configured" and the game falls back to simulated rivals.

### Anti-cheat: move-replay verification
The server does not trust scores sent by the device. A run counts only if the player's move log replays to a full clear on the board the server seeded.
- `/api/run` returns a signed token and a random seed. The seed is derived from the token with HMAC on the server, so the player can't choose or predict it.
- The game plays with `src/core.js`, the same deterministic rules the server uses. Board generation, waves, seals and auto-reshuffles all come from the seed, so the same moves always give the same result.
- `/api/league` replays the moves (`src/server/replay.js`). It rejects tapping locked or hidden tiles, moves faster than 120 ms apart, moves after the board is cleared, and logs that don't clear the board. It computes the score itself. The run is claimed atomically after the replay passes, so each run is accepted once.
- Limits: a bot that solves each board in real time can still post valid, high scores. This makes cheating much harder, but a top score isn't proof of skill. Booster stock and coin rewards are still kept on the device. Rush time is reported by the client and only bounded by the clock and run length, so the time bonus (at most a few hundred points) is the least certain part. Before a public launch, add Cloudflare Turnstile and tighter per-account rate limits.

## The 5000 levels
`src/levels.js` defines every level from its number (no stored data), so level N is identical for every player and on the server.
- **Worlds:** 50 worlds of 100 levels (Serengeti, Sahara Gate, Nile Delta ... Kingdom of Gold). Backgrounds and music cycle through 7 themes.
- **Board size:** 24 tiles at level 1, growing to 64 by level 600; boss levels add 8 more.
- **Layouts:** symmetric boards generated from the level number; from level 30 every 4th level uses one of the 7 handcrafted boards.
- **Tile types:** 4 at the start, +1 every 5 levels, 16 from level 61.
- **Sealed tiles (hard mode):** from level 15; more of them every 60 levels, and longer unlock gaps every 800.
- **Special levels** (every 5th) pay double coins; **boss levels** (every 25th) pay triple and are bigger. Rewards grow by 2 coins per 100 levels.
- **Level 5000** shows a champion message and can be replayed.
Tune the curve in `levelSpec()`.

## Board dynamics ("twists")
From level 8 each level can carry a twist, chosen from its number (`levelSpec().mods`):
- **🌫️ Fog:** locked tiles are hidden (shown face down) until they become free.
- **🌊 Waves:** the highest ~30% of tiles start hidden and drop in on top of the board at 25% / 50% (/ 70% on bosses) of the pairs matched, or immediately if you run out of moves.
- **⏱️ Rush:** a countdown (shrinks as levels rise). Leftover seconds become bonus points; when time runs out you can retry or buy +30 s for 50 coins.
- **Bosses** (every 25th level) combine Waves and Rush. Each twist shows a short explanation the first time you meet it.

Smoothness: tiles drop in with a staggered animation, move with spring-like transitions, tumble away when matched, flip on shuffle, and screens and popups fade or scale in. The timer has its own component so the board doesn't re-render while it ticks. All motion is disabled for players who prefer reduced motion.

## Privacy and store listing
- `public/privacy.html` is the privacy policy page (it ships with the site at `/privacy.html` and is linked from Settings). Fill in the `[BRACKETED]` fields and have it reviewed for your jurisdiction.
- `docs/store-listing.md` has draft store text, keywords, content-rating facts and data-safety answers.
- Settings → Delete online data calls `functions/api/delete.js`. Daily scores are deleted after 90 days and run records after about 2 days (housekeeping runs on a small share of requests).

## Weekly league (promotion and demotion)
- Five leagues: Bronze, Silver, Gold, Platinum, Epic. Players are seated in groups of up to 30 within their league.
- Points = what you score on cleared levels that week (same validated, single-use run tokens as the daily board).
- At the end of the week (Monday 00:00 UTC) the top 5 of a group move up and the bottom 5 move down (only in groups of 8 or more; players who never scored don't move up, and nobody drops below Bronze). Players who skip a week keep their league.
- Settling is lazy: it happens the first time a player is seen in the new week, so no scheduled job is needed. See `src/server/league.js`; tuning constants (`GROUP`, `PROMOTE`, `DEMOTE`) are at the top.
- D1 tables `ptier` and `members` were added to the `africa-mahjong-league` database. Run `functions/api/week.js` via `GET /api/week?pid=...`.
- Groups fill with real players only. With few players the groups are small, so promotion and demotion start to matter once a league has 8+ players.

### Weekly chest
When a week settles, a chest is waiting: coins by result (promotion pays most; podium finishes add a bonus) plus boosters for promotion or a top-3 finish. It is opened from the league popup via `POST /api/claim`, which is atomic and single-use, so it can't be claimed twice. A red dot on the 🏆 button shows an unopened chest. Reward amounts are in `rewardFor()` in `src/server/league.js`.

## Background music (optional)
- By default the game plays built-in procedural music.
- To use your own track, set `VITE_MUSIC_URL` (for example in `.env.local`) to a file under `public/`.
- `public/audio/local/` and `.env.local` are git-ignored and left out of the project zip. Commercial songs need a license before any public release, so remove them before building for the stores.

## Automatic deploys (GitHub Actions)
`.github/workflows/deploy.yml` builds and deploys to Cloudflare Pages on every push to `main`. Add these repository secrets first (Settings → Secrets and variables → Actions):
- `CLOUDFLARE_API_TOKEN`: an API token with "Cloudflare Pages: Edit" permission
- `CLOUDFLARE_ACCOUNT_ID`: your account ID from the Cloudflare dashboard

The `LEAGUE_SECRET` used by the league is set separately with `wrangler pages secret put`, as described above.
