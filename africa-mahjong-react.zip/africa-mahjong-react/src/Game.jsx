import { useEffect, useMemo, useReducer, useRef, useState } from "react";
import { BG, nm, art } from "./data.js";
import { levelSpec, WORLDS, MAX_LEVEL } from "./levels.js";
import { createRun, apply, findPair, isFree, isCleared, visibleOf, timeBonus, MIN_GAP_MS } from "./core.js";
import { music, sfx, vib, burst } from "./engine.js";
import { startRun, submitRun } from "./api.js";

const AV = ["👩🏾", "👨🏿", "👧🏽", "👴🏾", "🧑🏿", "👩🏿", "🧔🏾"];
const hash = (s) => [...s].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);
const MODE_INFO = {
  fog: ["🌫️ Fog", "Locked tiles are hidden until they become free."],
  waves: ["🌊 Waves", "Extra tiles drop in on top as you make matches. Plan ahead!"],
  rush: ["⏱️ Rush", "Beat the clock. Leftover seconds become bonus points."],
};
const calcU = () => Math.max(14, Math.min(36, Math.floor((innerWidth - 34) / 17), Math.floor((innerHeight - 340) / 13.5)));

/** Rush countdown. The clock lives in a ref, so only this bar re-renders as it ticks. */
function TimerBar({ clock, total, paused, onEnd }) {
  const [, force] = useReducer((x) => x + 1, 0);
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const endRef = useRef(onEnd);
  endRef.current = onEnd;
  useEffect(() => {
    const iv = setInterval(() => {
      const c = clock.current;
      if (pausedRef.current || c.stop) return;
      c.t += 0.25;
      if (c.t >= total + c.extra) { c.stop = true; endRef.current(); }
      force();
    }, 250);
    return () => clearInterval(iv);
  }, []);
  const all = total + clock.current.extra, left = Math.max(0, all - clock.current.t);
  return (
    <div className={"tbar" + (left < 15 ? " low" : "")}>
      <i style={{ width: (left / all) * 100 + "%" }} />
      <span>⏱️ {Math.floor(left / 60)}:{String(Math.floor(left % 60)).padStart(2, "0")}</span>
    </div>
  );
}

export default function Game({ S, up, toast, open, go, restart, paused }) {
  const spec = useMemo(() => levelSpec(S.lvl), []);
  const theme = spec.theme, hard = spec.seals > 0;
  const [run, setRun] = useState(null);            // { token, seed, online }
  const [st, setSt] = useState(null);              // current board state (from core.js)
  const [fail, setFail] = useState("");
  const [U, setU] = useState(calcU());
  const [hintIdx, setHintIdx] = useState([]);
  const [fresh, setFresh] = useState(true);
  const [shuf, setShuf] = useState(false);

  const stRef = useRef(null), runRef = useRef(null), logRef = useRef([]);
  const t0 = useRef(0), lastT = useRef(-1e9), over = useRef(false), extras = useRef(0);
  const clock = useRef({ t: 0, extra: 0, stop: false });
  const timeUpRef = useRef(null), hintTimer = useRef(null);

  // 1. Get a run (token and seed) from the server, then build the same board the server will replay.
  useEffect(() => {
    let alive = true;
    startRun(S.pid, S.lvl).then((r) => {
      if (!alive) return;
      const rr = r && r.token
        ? { token: r.token, seed: r.seed >>> 0, online: true }
        : { token: null, seed: (Math.random() * 4294967296) >>> 0, online: false }; // offline: plays, can't post
      try {
        const s0 = createRun(spec, rr.seed);
        runRef.current = rr; stRef.current = s0; t0.current = performance.now();
        setRun(rr); setSt(s0);
      } catch { setFail("Couldn't build this board. Please try again."); }
    });
    const f = setTimeout(() => setFresh(false), 1300);
    const rs = () => setU(calcU());
    addEventListener("resize", rs);
    return () => { alive = false; clearTimeout(f); clearTimeout(hintTimer.current); removeEventListener("resize", rs); };
  }, []);

  const ready = !!st;
  useEffect(() => { music(true, theme); return () => music(false, theme); }, [theme, S.mute]);
  useEffect(() => {
    if (!ready) return;
    if (S.seen < 2) { up((s) => { s.seen = 2; }); open({ kind: "help" }); }
    else if (hard && !S.hs) { up((s) => { s.hs = 1; }); open({ kind: "hard" }); }
    else {
      const nu = Object.keys(spec.mods).filter((k) => spec.mods[k] && !S.sm.includes(k));
      if (nu.length) {
        up((s) => { s.sm.push(...nu); });
        open({ kind: "custom", title: "New twist!", body: nu.map((k) => <p key={k}><b>{MODE_INFO[k][0]}</b><br />{MODE_INFO[k][1]}</p>), btns: [{ t: "Let's go" }] });
      }
    }
  }, [ready]);

  const showHint = (idx) => {
    setHintIdx(idx);
    clearTimeout(hintTimer.current);
    hintTimer.current = setTimeout(() => setHintIdx([]), 2200);
  };

  /** Applies one action through the shared rules. Returns {prev, next}, or null if the move is illegal or too fast. */
  const dispatch = (act) => {
    const cur = stRef.current;
    if (!cur || !runRef.current || over.current) return null;
    const t = Math.round(performance.now() - t0.current);
    if (t - lastT.current < MIN_GAP_MS) return null; // the server enforces the same gap
    let next;
    try { next = apply(cur, { ...act, t }); } catch { return null; }
    lastT.current = t;
    logRef.current.push({ ...act, t });
    stRef.current = next;
    setSt(next);
    setHintIdx([]);
    if (next.sh > cur.sh && act.k !== "s") toast("No moves left: board reshuffled");
    if ((next.rw || 0) > (cur.rw || 0)) toast("Dead end: rewound to the last playable position");
    if (next.wave > cur.wave) { sfx.sp(); vib(20); toast("🌊 Wave " + next.wave + " arrives!"); }
    if (cur.mc !== 99 && next.mc === 99) toast("Seals broken!");
    return { prev: cur, next };
  };

  const onTile = (i) => {
    const r = dispatch({ k: "p", i });
    if (!r) return;
    const { prev, next } = r, sym = prev.T[i].s;
    if (next.score > prev.score) {
      if (sym === 16) { sfx.sp(); const p = findPair(next); if (p) showHint(p); }
      else if (sym === 17) { sfx.sp(); toast("🌧️ Rain reshuffled the board"); }
      else sfx.ok();
      vib(15);
      burst({ el: document.getElementById("t" + i) }, 8);
      if (prev.sel !== null) burst({ el: document.getElementById("t" + prev.sel) }, 8);
      if (next.combo > 1) toast(`Combo x${next.combo}  +${next.score - prev.score}`);
      else if (sym !== 16 && sym !== 17) toast(nm(sym, S.theme));
      up((s) => { s.mt++; });
    } else if (next.sel === i && prev.sel !== null) {
      sfx.bad(); // mismatch: the selection moved to the new tile
    } else if (next.sel === i) {
      sfx.sel();
    }
  };

  const boostShuffle = () => {
    if (S.b.s < 1) return toast("No shuffles left. Clear boards to earn more.");
    if (!dispatch({ k: "s" })) return;
    up((s) => { s.b.s--; });
    setShuf(true); setTimeout(() => setShuf(false), 650);
    toast("Board shuffled");
  };
  const boostHint = () => {
    if (S.b.h < 1) return toast("No hints left. Clear boards to earn more.");
    const p = findPair(stRef.current);
    if (!p) return toast("No free pair right now");
    up((s) => { s.b.h--; });
    showHint(p);
  };
  const boostUndo = () => {
    if (S.b.u < 1) return toast("No undos left. Clear boards to earn more.");
    if (!stRef.current.hist.length) return toast("Nothing to undo");
    if (!dispatch({ k: "u" })) return;
    up((s) => { s.b.u--; s.mt = Math.max(0, s.mt - 1); });
  };

  const buyTime = () => {
    if (S.coins < 50) return toast("Not enough coins");
    if (!dispatch({ k: "x" })) return toast("Wait a moment and try again");
    up((s) => { s.coins -= 50; });
    extras.current++;
    clock.current.extra += 30;
    clock.current.stop = false;
  };

  const timeUp = () => {
    if (over.current) return;
    clock.current.stop = true;
    open({
      kind: "custom", noclose: 1, title: "Time's up! ⏱️",
      body: <p>The clock ran out. Add 30 seconds for 🪙50, or try again.</p>,
      btns: [
        ...(S.coins >= 50 ? [{ t: "+30s (🪙50)", cb: buyTime }] : []),
        { t: "Retry", o: 1, cb: restart },
        { t: "Home", o: 1, cb: () => go("home") },
      ],
    });
  };
  timeUpRef.current = timeUp;

  const pause = () => open({
    kind: "custom", noclose: 1, title: "Paused",
    body: <p>Leave this level? Your progress on this board will be lost.</p>,
    btns: [{ t: "Keep playing" }, { t: "Restart", o: 1, cb: restart }, { t: "Home", o: 1, cb: () => go("home") }],
  });

  // 2. When the board is cleared: submit the move log, show the server-verified result.
  const cleared = !!st && isCleared(st);
  useEffect(() => {
    if (!cleared || over.current) return;
    over.current = true; clock.current.stop = true;
    sfx.win(); vib([80, 40, 80]);
    const bd = document.getElementById("board");
    for (let i = 0; i < 4; i++) setTimeout(() => burst({ el: bd }, 30, 240), i * 220);
    const timeUsed = Math.round(clock.current.t * 100) / 100;
    const localScore = stRef.current.score + timeBonus(spec, timeUsed, extras.current);
    const actions = logRef.current.slice(), token = runRef.current && runRef.current.token;
    const pid = S.pid, name = S.name;
    (async () => {
      const res = token ? await submitRun(token, pid, name, actions, timeUsed) : null;
      const score = res ? res.score : localScore;
      let podium, rank, weekly = null;
      if (res) {
        podium = (res.top || []).map((p) => ({ n: p.name, a: AV[hash(p.name) % AV.length], s: p.score, me: p.score === score && p.name === name }));
        rank = res.rank;
        weekly = res.weekly || null;
      } else {
        const bots = [["Amara", "👩🏾"], ["Kofi", "👨🏿"], ["Zuri", "👧🏽"], ["Tendai", "👴🏾"]]
          .map((b) => ({ n: b[0], a: b[1], s: Math.round((score * (0.6 + Math.random() * 0.65)) / 10) * 10 }));
        const all = [{ n: "You", a: "🧑🏾", s: score, me: 1 }, ...bots].sort((x, y) => y.s - x.s);
        podium = all.slice(0, 3);
        rank = all.findIndex((p) => p.me) + 1;
      }
      const coins = spec.reward + (4 - Math.min(rank, 4)) * 10;
      const booster = ["s", "h", "u"][(Math.random() * 3) | 0];
      up((s) => { s.cl++; if (rank === 1) s.wins++; });
      const note = !token ? "Offline: this score isn't on the league." : !res ? "The league couldn't verify this run, so it isn't posted." : "";
      open({
        kind: "custom", noclose: 1,
        title: S.lvl >= MAX_LEVEL ? "Champion of Africa! 👑" : rank === 1 ? "First place! 🏆" : "Level cleared!",
        body: (<>
          <p><b>Score {score}</b>{note ? <><br /><small>{note}</small></> : null}</p>
          <div className="pod">{[1, 0, 2].map((i) => podium[i] ? (
            <div key={i} className={"pc" + (podium[i].me ? " me" : "")}>
              <div className="pav">{podium[i].a}<small>{podium[i].me ? "YOU " : ""}{podium[i].s}</small></div>
              <div className={"ped p" + (i + 1)}>{i + 1}</div>
            </div>) : <div key={i} className="pc" />)}</div>
          <p>{rank > 3 ? `You placed ${rank}th today. ` : ""}You placed <b>#{rank}</b> today{weekly ? ` · weekly ${weekly.tierName} #${weekly.rank} of ${weekly.size}` : ""} · reward <b>🪙{coins}</b> + a free booster</p>
          <div className="gift">🎁</div>
        </>),
        btns: [{ t: "Collect", cb: () => { up((s) => { s.coins += coins; s.b[booster]++; s.lvl = Math.min(MAX_LEVEL, s.lvl + 1); }); go("home"); toast("+🪙" + coins); } }],
      });
    })();
  }, [cleared]);

  // 3. Dead end: no pair can be reached from here. Offer Undo (if available) or a fresh start.
  useEffect(() => {
    if (!st || cleared || over.current || findPair(st)) return;
    clock.current.stop = true;
    open({
      kind: "custom", noclose: 1, title: "No moves left",
      body: <p>No pair can be reached from this position. Undo a move or start the board again.</p>,
      btns: [
        ...(stRef.current.hist.length && S.b.u > 0 ? [{ t: "Undo (↩️)", cb: () => { clock.current.stop = false; boostUndo(); } }] : []),
        { t: "Restart board", o: 1, cb: restart },
        { t: "Home", o: 1, cb: () => go("home") },
      ],
    });
  }, [st]);

  if (fail) return (
    <div id="game" className="scr" style={{ background: BG[theme] }}>
      <p style={{ margin: "auto", textAlign: "center" }}>{fail}</p>
      <button className="big" onClick={() => go("home")}>Home</button>
    </div>
  );
  if (!st) return <div id="game" className="scr" style={{ background: BG[theme] }}><p style={{ margin: "auto" }}>Building board…</p></div>;

  const vis = visibleOf(st.T);
  const rem = st.T.filter((t) => !t.gone).length;
  const title = `${WORLDS[spec.world]} · Level ${S.lvl}${spec.boss ? " 👑" : hard ? " 🔒" : ""}${spec.mods.fog ? " 🌫️" : ""}${spec.mods.waves ? " 🌊" : ""}${spec.mods.rush ? " ⏱️" : ""}`;

  return (
    <div id="game" className="scr" style={{ background: BG[theme] }}>
      <div className="gt">
        <button className="rb" aria-label="Back" onClick={pause}>←</button>
        <div id="gs">{st.score}</div>
        <button className="rb" aria-label="Menu" onClick={pause}>☰</button>
      </div>
      <div id="plank">
        <div><span>{title}</span><span>{rem / 2} pairs left</span></div>
        <div className="pbar"><i style={{ width: 100 - (rem / st.T.length) * 100 + "%" }} /></div>
        {spec.timeSec > 0 && <TimerBar clock={clock} total={spec.timeSec} paused={paused} onEnd={() => timeUpRef.current && timeUpRef.current()} />}
      </div>
      <div id="wrap">
        <div id="board" style={{ width: 16 * U + 10, height: 12.5 * U + 12 }}>
          {st.T.map((t) => {
            const free = !t.gone && !t.hid && isFree(t, vis);
            const sl = !t.gone && !t.hid && t.seal > st.mc;
            const lock = !t.gone && !t.hid && (!free || sl);
            const fog = spec.mods.fog && lock;
            const cls = ["t", t.s > 15 && "sp", t.gone && "gone", lock && "lock", sl && "seal", st.sel === t.i && "sel",
              hintIdx.includes(t.i) && "hint", t.hid && "hid", fog && "fog", fresh && !t.hid && "rise", shuf && "shuf"].filter(Boolean).join(" ");
            return (
              <button key={t.i} id={"t" + t.i} className={cls} data-k={t.seal - st.mc} aria-label={fog ? "Hidden tile" : nm(t.s, S.theme)}
                onClick={() => onTile(t.i)}
                style={{ left: t.x * U - t.z * 5, top: t.y * U * 1.25 - t.z * 5, width: 2 * U, height: 2.5 * U, zIndex: t.z * 10 + (t.y | 0), animationDelay: (t.i % 30) * 14 + "ms" }}>
                <svg viewBox="0 0 24 24" style={{ width: U * 1.65, height: U * 1.65 }} dangerouslySetInnerHTML={{ __html: art(t.s, S.theme) }} />
              </button>
            );
          })}
        </div>
      </div>
      <div className="boost">
        <button aria-label="Shuffle" onClick={boostShuffle}>🔀<i>{S.b.s}</i></button>
        <button aria-label="Hint" onClick={boostHint}>💡<i>{S.b.h}</i></button>
        <button aria-label="Undo" onClick={boostUndo}>↩️<i>{S.b.u}</i></button>
      </div>
    </div>
  );
}
