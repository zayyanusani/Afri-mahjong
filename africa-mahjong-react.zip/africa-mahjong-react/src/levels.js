// 5000 deterministic levels. Every level has a fixed layout, difficulty and reward derived from its number,
// so the client, the tests and the Cloudflare league validation all agree on what level N looks like.
import { REG } from "./data.js";

export const MAX_LEVEL = 5000;

// 50 worlds of 100 levels each. The visual theme and music cycle through the 7 base themes.
export const WORLDS = [
  "Serengeti", "Sahara Gate", "Nile Delta", "Congo Basin", "Okavango", "Kilimanjaro", "Victoria Falls", "Namib Dunes", "Lake Malawi", "Ngorongoro",
  "Timbuktu", "Zanzibar", "Great Zimbabwe", "Lalibela", "Table Mountain", "Atlas Mountains", "Skeleton Coast", "Kruger", "Masai Mara", "Lake Turkana",
  "Rift Valley", "Danakil", "Ahaggar", "Tassili", "Fez Medina", "Giza Plateau", "Luxor", "Aswan", "Dakar Coast", "Lagos Lagoon",
  "Accra Shore", "Cape Coast", "Gorée Island", "Sossusvlei", "Etosha Pan", "Chobe River", "Zambezi", "Drakensberg", "Bwindi Forest", "Virunga",
  "Lake Victoria", "Lake Tanganyika", "Niger Bend", "Djenné", "Axum", "Meroë", "Baobab Avenue", "Seychelles Isles", "Mount Kenya", "Kingdom of Gold",
];
export const worldOf = (lvl) => Math.min(WORLDS.length - 1, ((lvl - 1) / 100) | 0);
export const themeOf = (lvl) => worldOf(lvl) % 7;

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), a | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Left-right symmetric layout on the 15 x 9 half-tile grid. Always an even number of tiles. */
function gen(lvl, target) {
  const r = rng(lvl * 7919 + 13), used = new Set(), tiles = [];
  const add = (x, y, z) => { const k = x + "," + y + "," + z; if (used.has(k)) return; used.add(k); tiles.push({ x, y, z }); };
  const keep = Math.min(0.95, Math.max(0.45, Math.min(target, 40) / 40));
  for (let row = 0; row < 5; row++) for (let c = 0; c < 4; c++) if (r() < keep) { add(c * 2, row * 2, 0); add((7 - c) * 2, row * 2, 0); }
  if (tiles.length < 8) { add(6, 4, 0); add(8, 4, 0); add(4, 4, 0); add(10, 4, 0); }
  for (let z = 1; z <= 4 && tiles.length < target; z++) {
    const cand = [];
    for (let y = z; y <= 8 - z; y += 2) for (let x = z; x < 7; x += 2) cand.push([x, y]);
    cand.sort(() => r() - 0.5);
    for (const [x, y] of cand) { if (tiles.length >= target) break; add(x, y, z); add(14 - x, y, z); }
  }
  return tiles;
}

// Board dynamics ("twists"): fog hides locked tiles, waves drop extra tiles in as you match, rush adds a countdown.
const MODES = [[], ["fog"], ["waves"], ["rush"], [], ["fog", "rush"], ["waves", "fog"]];
const cache = new Map();

export function levelSpec(level) {
  const lvl = Math.max(1, Math.min(MAX_LEVEL, level | 0));
  if (cache.has(lvl)) return cache.get(lvl);
  const boss = lvl % 25 === 0, special = lvl % 5 === 0;
  let target = 24 + Math.round(Math.min(1, (lvl - 1) / 600) * 40) + (boss ? 8 : 0); // 24 tiles at level 1, 64 by level 600, 72 on bosses
  target -= target % 2;
  const hand = lvl >= 30 && lvl % 4 === 0 && !boss; // every 4th level from 30 uses a handcrafted board
  const layout = hand ? REG[(((lvl / 4) | 0) + lvl) % REG.length].l.map((p) => ({ ...p })) : gen(lvl, target);
  const spec = {
    lvl, boss, special, world: worldOf(lvl), theme: themeOf(lvl), layout, tiles: layout.length, pairs: layout.length / 2,
    K: Math.min(16, 4 + (((lvl - 1) / 5) | 0)),                                   // tile types: 4 at the start, 16 from level 61
    seals: lvl >= 15 ? Math.min(12, 2 + (((lvl - 15) / 60) | 0) + (boss ? 2 : 0)) : 0, // sealed tiles from level 15
    sealStep: 2 + ((lvl / 800) | 0),                                               // matches between seal unlocks grows slowly
    reward: (20 + ((lvl / 100) | 0) * 2) * (boss ? 3 : special ? 2 : 1),
  };
  const m = boss ? ["waves", "rush"] : lvl < 8 ? [] : MODES[(lvl - 8 + spec.world) % 7];
  spec.mods = { fog: m.includes("fog"), waves: m.includes("waves"), rush: m.includes("rush") };
  spec.waves = spec.mods.waves ? (boss ? 3 : 2) : 0;
  spec.timeSec = spec.mods.rush ? Math.round((spec.pairs * 12 + 20) * Math.max(0.55, 1 - lvl / 3000)) : 0;
  cache.set(lvl, spec);
  if (cache.size > 24) cache.delete(cache.keys().next().value);
  return spec;
}
