import { useEffect, useState } from "react";
import { TASKS } from "./data.js";
import { MAX_LEVEL } from "./levels.js";
import { getWeek } from "./api.js";

const pad = (v) => String(v).padStart(2, "0");
function untilMidnight() {
  const n = new Date(), e = new Date(n);
  e.setUTCHours(24, 0, 0, 0);
  const s = Math.floor((e - n) / 1000);
  return `${pad((s / 3600) | 0)}:${pad(((s % 3600) / 60) | 0)}:${pad(s % 60)}`;
}

export default function Home({ S, up, open, special, play }) {
  useEffect(() => { // refresh league tier and the unopened-chest dot (only for players who have started)
    if (S.lvl > 1) getWeek(S.pid).then((r) => { if (r) up((s) => { s.tier = r.tier; s.chest = !!(r.prev && !r.prev.claimed); }); });
  }, []);
  const [tm, setTm] = useState(untilMidnight());
  useEffect(() => { const i = setInterval(() => setTm(untilMidnight()), 1000); return () => clearInterval(i); }, []);
  const boss = S.lvl % 25 === 0;
  const dot = TASKS.some((t, i) => S[t[1]] >= t[2] && !S.cc[i]);
  return (
    <div id="home" className="scr">
      <div className="top">
        <div className="av" onClick={() => open({ kind: "journey" })}>🧑🏾<i>{S.lvl}</i></div>
        <div className="pill" onClick={() => open({ kind: "shop" })}>🪙 x{S.coins} ＋</div>
        <span className="sp" />
        <button className="rb" aria-label="Settings" onClick={() => open({ kind: "settings" })}>⚙️</button>
      </div>
      <div className="logo"><span className="l1">Africa</span><span className="l2">MAHJONG</span></div>
      <div className="mid">
        <button className="side" onClick={() => open({ kind: "tasks" })}>
          <div className="ic">📋{dot && <span className="dot" />}</div><div className="lab">Task</div>
        </button>
        <button className="med" aria-label="Play" onClick={play}><div className="ring" /><div className="core">🦁</div></button>
        <button className="side" onClick={() => open({ kind: "league" })}>
          <div className="ic">{["🥉", "🥈", "🥇", "💎", "👑"][S.tier || 0]}{S.chest && <span className="dot" />}</div><div className="lab">{tm}</div>
        </button>
      </div>
      <div className="bot">
        {(boss || special) && <div id="spl">{boss ? "👑 Boss" : "Special"}</div>}
        <button className="big" onClick={play}>Level {S.lvl}<small style={{ fontSize: 14, opacity: 0.8 }}> / {MAX_LEVEL}</small></button>
      </div>
    </div>
  );
}
