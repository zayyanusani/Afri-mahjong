import { useEffect, useState } from "react";
import { TASKS } from "./data.js";
import { WORLDS, MAX_LEVEL } from "./levels.js";
import { getTop, getWeek, deleteData, claimChest } from "./api.js";
import { sfx } from "./engine.js";
import { today } from "./store.js";

const IC = ["🌾", "🌊", "🌴", "🏜️", "🏛️", "💧", "🏔️"];
const DAILY = [20, 30, 40, 50, 60, 80, 150];

const TIER_ICON = ["🥉", "🥈", "🥇", "💎", "👑"];

/** This week's league group: promotion zone (top 5) and demotion zone (bottom 5) are shaded. */
function Weekly({ S, up, toast }) {
  const [d, setD] = useState(null), [prev, setPrev] = useState(null);
  useEffect(() => {
    getWeek(S.pid).then((r) => {
      setD(r);
      if (r) { setPrev(r.prev && (!r.prev.claimed || r.prev.week !== S.lw) ? r.prev : null); up((s) => { s.tier = r.tier; s.chest = !!(r.prev && !r.prev.claimed); if (r.prev) s.lw = r.prev.week; }); }
    });
  }, []);
  if (d === null) return <p><small>Loading your league…</small></p>;
  if (!d) return <p><small>Weekly league unavailable offline.</small></p>;
  const left = Math.max(0, d.endsAt - Date.now()), days = Math.floor(left / 864e5), hrs = Math.floor((left % 864e5) / 36e5);
  const zone = (i) => (d.size >= 8 && i >= d.size - d.demote ? " dem" : i < d.promote ? " pro" : "");
  return (<>
    <div style={{ fontSize: 44 }}>{TIER_ICON[d.tier]}</div>
    <p><b>{d.tierName} League</b> · ends in {days}d {hrs}h</p>
    {prev && <div style={{ background: "rgba(224,165,38,.25)", borderRadius: 10, padding: 8, margin: "8px 0" }}>
      <div>{prev.to > prev.from ? `🎉 Last week you finished #${prev.rank} and were promoted to ${prev.toName}!` : prev.to < prev.from ? `Last week you finished #${prev.rank} and moved down to ${prev.toName}.` : `Last week you finished #${prev.rank} and stayed in ${prev.toName}.`}</div>
      {!prev.claimed && <button className="go o" style={{ marginTop: 8, fontSize: 20, padding: 8 }} onClick={async () => {
        const res = await claimChest(S.pid);
        if (!res) return toast("Couldn't open the chest, try again");
        up((s) => { s.coins += res.reward.coins; ["s", "h", "u"].forEach((k) => { s.b[k] += res.reward.boosters[k]; }); s.chest = false; });
        setPrev({ ...prev, claimed: true }); toast("+🪙" + res.reward.coins); sfx.ok();
      }}>🎁 Open chest (+🪙{prev.reward.coins})</button>}
    </div>}
    <div style={{ maxHeight: "30vh", overflowY: "auto" }}>
      {d.rows.map((p, i) => (
        <div className={"row lg" + zone(i) + (p.me ? " me" : "")} key={i}><div>{i + 1}. {p.me ? "You" : p.name}</div><b>{p.score}</b></div>))}
    </div>
    <p><small>Top {d.promote} move up · bottom {d.demote} move down. Points are what you score on cleared levels this week.</small></p>
  </>);
}

function Top() {
  const [t, setT] = useState(null);
  useEffect(() => { getTop().then(setT); }, []);
  if (t === null) return <p><small>Loading today's leaderboard…</small></p>;
  if (t === false) return <p><small>Leaderboard unavailable offline.</small></p>;
  if (!t.length) return <p><small>No scores yet today. Be the first!</small></p>;
  return t.slice(0, 5).map((p, i) => <div className="row" key={i}><div>{i + 1}. {p.name}</div><b>{p.score}</b></div>);
}

export default function ModalHost({ m, ctx }) {
  const { S, up, toast, open, close, go, install, standalone } = ctx;
  let title = "", body = null, btns = [], canClose = !m.noclose;

  switch (m.kind) {
    case "custom": title = m.title; body = m.body; btns = m.btns || []; break;

    case "tasks":
      title = "Daily tasks";
      body = TASKS.map((t, i) => {
        const v = Math.min(S[t[1]], t[2]), ok = v >= t[2] && !S.cc[i];
        return (
          <div className="row" key={i}>
            <div>{t[0]}<br /><small>{v}/{t[2]} · reward 🪙{t[3]}</small></div>
            <button disabled={!ok} onClick={() => { up((s) => { s.cc[i] = 1; s.coins += t[3]; }); sfx.ok(); }}>{S.cc[i] ? "Done" : "Claim"}</button>
          </div>);
      });
      break;

    case "league":
      title = "Savanna League";
      body = (<>
        <div style={{ fontSize: 38, letterSpacing: 4 }}>🥉🥈🥇💎👑</div>
        <p>Clear levels to earn points. Each week you compete in a group of up to 30. At the end of the week (Monday 00:00 UTC) the top 5 move up a league and the bottom 5 move down.</p>
        <p>First places won: <b>{S.wins}</b></p>
        <Weekly S={S} up={up} toast={toast} />
        <p><b>Today's top players</b></p>
        <Top />
      </>);
      btns = [{ t: "Play", cb: () => go("game") }];
      break;

    case "settings":
      title = "Settings";
      body = (<>
        <div className="row"><div>Sound</div><button onClick={() => up((s) => { s.mute = s.mute ? 0 : 1; })}>{S.mute ? "Off" : "On"}</button></div>
        <div className="row"><div>How to play</div><button onClick={() => open({ kind: "help" })}>Show</button></div>
        {!standalone && (
          <div className="row"><div>Install app<br /><small>{install ? "Add to your home screen" : "Browser menu → Add to Home Screen"}</small></div>
            {install && <button onClick={install}>Install</button>}</div>)}
        <div className="row"><div>Player name<br /><small>{S.name || "Set after your first win"}</small></div>
          <button onClick={() => { const n = (prompt("Your name (max 16 characters)", S.name || "") || "").replace(/[^\p{L}\p{N} _-]/gu, "").slice(0, 16); if (n) up((s) => { s.name = n; if (!s.pid) s.pid = crypto.randomUUID(); }); }}>Edit</button></div>
        <div className="row"><div>Delete online data<br /><small>Removes your name and scores from the league</small></div>
          <button onClick={async () => { if (!confirm("Delete your online leaderboard data?")) return; toast((await deleteData(S.pid)) ? "Online data deleted" : "Couldn't reach the server"); }}>Delete</button></div>
        <div className="row"><div>Privacy policy</div><a href="privacy.html" target="_blank" rel="noopener">Open</a></div>
        <div className="row"><div>Reset progress</div><button onClick={() => { try { localStorage.removeItem("am2"); } catch { /* ignore */ } location.reload(); }}>Reset</button></div>
      </>);
      break;

    case "help":
      title = "How to play";
      body = (<>
        <p>Tap two identical tiles to clear them.</p>
        <p>A tile is <b>free</b> when nothing sits on top and its left or right side is open. Dimmed tiles are locked.</p>
        <p>Gold tiles are special: ☀️ shows a hint, 🌧️ reshuffles. Match quickly for combo points.</p>
      </>);
      btns = [{ t: "Got it" }];
      break;

    case "hard":
      title = "Hard mode 🔒";
      body = (<>
        <p>From level 15, some tiles are <b>sealed</b>. A sealed tile shows a lock and a number: it unlocks after that many matches on the board.</p>
        <p>More tile types also appear. Plan your matches, and use Hint when stuck.</p>
      </>);
      btns = [{ t: "Let's go" }];
      break;

    case "shop": {
      const owned = S.own.includes("adinkra");
      title = "Shop 🪙" + S.coins;
      body = (<>
        <div className="row"><div>Adinkra tile set<br /><small>Symbols of the Akan people · 200 🪙</small></div>
          <button disabled={S.theme === "adinkra"} onClick={() => {
            if (!owned && S.coins < 200) return toast("Not enough coins");
            up((s) => { if (!owned) { s.coins -= 200; s.own.push("adinkra"); } s.theme = "adinkra"; });
          }}>{owned ? (S.theme === "adinkra" ? "Equipped" : "Equip") : "Buy"}</button></div>
        <div className="row"><div>Animal tile set<br /><small>Default</small></div>
          <button disabled={S.theme === "animals"} onClick={() => up((s) => { s.theme = "animals"; })}>{S.theme === "animals" ? "Equipped" : "Equip"}</button></div>
        {[["s", "Shuffle", "🔀"], ["h", "Hint", "💡"], ["u", "Undo", "↩️"]].map((b) => (
          <div className="row" key={b[0]}><div>{b[2]} {b[1]} +1<br /><small>You have {S.b[b[0]]} · 40 🪙</small></div>
            <button onClick={() => { if (S.coins < 40) return toast("Not enough coins"); up((s) => { s.coins -= 40; s.b[b[0]]++; }); sfx.ok(); }}>Buy</button></div>))}
      </>);
      break;
    }

    case "journey": {
      title = `Journey · ${S.lvl}/${MAX_LEVEL}`;
      const a = Math.max(1, S.lvl - 3), rows = [];
      for (let l = Math.min(MAX_LEVEL, S.lvl + 8); l >= a; l--) {
        const done = l < S.lvl, cur = l === S.lvl, sp = l % 5 === 0, off = [0, 34, 68, 34][l % 4], w = ((l - 1) / 100) | 0;
        rows.push(
          <div key={l} style={{ marginLeft: off, display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <div style={{ width: 46, height: 46, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", font: "20px 'Lilita One',sans-serif", color: "#fff",
              background: cur ? "linear-gradient(#ff9a3c,#d9611b)" : done ? "#2e9a2e" : "#9d927c", border: `4px solid ${sp ? "#E0A526" : "#6b3418"}` }}>{done ? "✓" : l}</div>
            <small>{l % 25 === 0 ? "👑 Boss · " : sp ? "⭐ " : ""}{IC[w % IC.length]} {WORLDS[w]}{cur ? " · you are here" : ""}</small>
          </div>);
      }
      body = (<><div style={{ textAlign: "left", paddingLeft: 8, maxHeight: "48vh", overflowY: "auto" }}>{rows}</div><small>⭐ Special levels pay double coins · 👑 Boss levels pay triple</small></>);
      btns = [{ t: "Play level " + S.lvl, cb: () => go("game") }];
      break;
    }

    case "daily": {
      const y = new Date(); y.setDate(y.getDate() - 1);
      const ns = S.last === y.toDateString() ? S.streak + 1 : 1, d = (ns - 1) % 7;
      title = "Daily reward";
      body = (<>
        <p>Day {ns} streak! Come back tomorrow for more.</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6 }}>
          {DAILY.map((c, i) => (
            <div key={i} style={{ borderRadius: 10, padding: "6px 0", background: i === d ? "#E0A526" : i < d ? "#b9ad95" : "rgba(120,90,50,.15)", color: i === d ? "#4a2a14" : "inherit" }}>
              <small>Day {i + 1}</small><br />{i === 6 ? "🎁" : "🪙"}<br /><b>{c}</b>
            </div>))}
        </div>
        {d === 6 && <p>Day 7 bonus: +1 of every booster!</p>}
      </>);
      btns = [{ t: "Claim", cb: () => { up((s) => { s.streak = ns; s.coins += DAILY[d]; s.last = today(); if (d === 6) { s.b.s++; s.b.h++; s.b.u++; } }); toast("+🪙" + DAILY[d]); } }];
      break;
    }
    default: return null;
  }

  return (
    <div id="pop" className="on">
      <div className="card">
        <div className="hd"><span>{title}</span>{canClose && <button onClick={close} aria-label="Close">✕</button>}</div>
        <div className="bd">
          {body}
          {btns.map((b, i) => (
            <button key={i} className={"go" + (b.o ? " o" : "")} onClick={() => { close(); b.cb && b.cb(); }}>{b.t}</button>))}
        </div>
      </div>
    </div>
  );
}
