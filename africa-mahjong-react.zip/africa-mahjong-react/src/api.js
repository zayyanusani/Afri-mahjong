// Set VITE_API_BASE (for example https://africa-mahjong.pages.dev) when building the Android/iOS app,
// because the native shell is not served from the same origin as the API.
const BASE = import.meta.env.VITE_API_BASE || "";
const JSON_HEADERS = { "content-type": "application/json" };

async function call(path, opts, ms = 3000) {
  const c = new AbortController(), t = setTimeout(() => c.abort(), ms);
  try {
    const r = await fetch(BASE + path, { ...opts, signal: c.signal });
    return r.ok ? await r.json() : null;
  } catch { return null; } finally { clearTimeout(t); }
}
const post = (path, body, ms) => call(path, { method: "POST", headers: JSON_HEADERS, body: JSON.stringify(body) }, ms);

/** Starts a run. Returns { token, seed }, or null when offline. The seed builds the board. */
export const startRun = (pid, lvl) => post("/api/run", { pid, lvl });

/** Sends the move log. The server replays it and returns the verified score, or null if rejected. */
export const submitRun = (token, pid, name, actions, timeUsed) => post("/api/league", { token, pid, name, actions, timeUsed }, 9000);

export const getTop = async () => (await call("/api/league"))?.top ?? false;
export const getWeek = async (pid) => (await call("/api/week?pid=" + encodeURIComponent(pid))) ?? false;
export const claimChest = (pid) => post("/api/claim", { pid });
export const deleteData = async (pid) => !!(await post("/api/delete", { pid }));
