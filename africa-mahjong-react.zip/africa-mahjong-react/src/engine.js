import {MUSIC} from "./data.js";
let muted=false;export const setMuted=m=>{muted=!!m};
// Board rules (fr, assign) now live in core.js so the browser and server share them.
let mi=null,mp=0;
// Optional background track. Set VITE_MUSIC_URL (see .env.example) to play a file instead of the built-in
// procedural music. Keep licensed tracks out of published builds unless you have the rights.
const TRACK = import.meta.env.VITE_MUSIC_URL || "";
let track = null;
export function music(on,idx){
  if(TRACK){
    if(!track){track=new Audio(TRACK);track.loop=true;track.volume=0.35;}
    if(on&&!muted)track.play().catch(()=>{});else track.pause();
    return;
  }
clearInterval(mi);mi=null;if(!on||muted)return;const m=MUSIC[idx];mi=setInterval(()=>{mp=Math.max(0,Math.min(9,mp+(Math.random()*3|0)-1));if(Math.random()<.25)return;tone(m.r*Math.pow(2,(m.s[mp%5]+12*(mp/5|0))/12),.9,0,m.w,.035);if(mp%4===0)tone(m.r/2,1.4,0,"sine",.03)},m.t)}
let AC=null;
export function tone(f,d,t0,ty,v){if(muted)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const o=AC.createOscillator(),g=AC.createGain(),s=AC.currentTime+(t0||0);o.type=ty||"sine";o.frequency.value=f;g.gain.setValueAtTime(v||.12,s);g.gain.exponentialRampToValueAtTime(.001,s+d);o.connect(g);g.connect(AC.destination);o.start(s);o.stop(s+d)}catch(e){}}
export const sfx={sel:()=>tone(520,.08),ok:()=>{tone(660,.15,0,"triangle");tone(880,.2,.09,"triangle")},bad:()=>tone(180,.15,0,"sawtooth",.05),sp:()=>{tone(990,.12);tone(1320,.2,.1)},win:()=>[523,659,784,1047].forEach((f,i)=>tone(f,.3,i*.12,"triangle"))};
export const vib=p=>{try{navigator.vibrate&&navigator.vibrate(p)}catch(e){}};
export function burst(t,n=8,sp=60){if(matchMedia("(prefers-reduced-motion:reduce)").matches)return;const r=t.el.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,C=["#E0A526","#B23A2E","#2F9E6B","#fff","#ff9a3c"];
for(let i=0;i<n;i++){const e=document.createElement("i"),a=Math.random()*6.28,d=sp*(.4+Math.random()*.8),s=4+Math.random()*6;
e.style.cssText=`position:fixed;left:${cx}px;top:${cy}px;width:${s}px;height:${s}px;border-radius:${Math.random()<.5?"50%":"2px"};background:${C[i%5]};pointer-events:none;z-index:70`;
document.body.appendChild(e);e.animate([{transform:"translate(0,0) rotate(0)",opacity:1},{transform:`translate(${Math.cos(a)*d}px,${Math.sin(a)*d+30}px) rotate(${Math.random()*360}deg) scale(.3)`,opacity:0}],{duration:600+Math.random()*400,easing:"cubic-bezier(.2,.7,.4,1)"}).onfinish=()=>e.remove()}}
