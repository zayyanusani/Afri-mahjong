// Signed run tokens (HMAC-SHA256). Used only by the Cloudflare Pages Functions.
const enc = new TextEncoder();
const key = (secret) => crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
const b64 = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
export const sign = async (secret, data) => b64(await crypto.subtle.sign("HMAC", await key(secret), enc.encode(data)));
export const validPid = (p) => /^[\w-]{8,64}$/.test(String(p || ""));

export async function makeToken(secret, pid, lvl) {
  const nonce = crypto.randomUUID(), started = Date.now(), body = [nonce, started, lvl, pid].join(".");
  return { nonce, started, token: body + "." + (await sign(secret, body)) };
}

/** Returns { nonce, started, lvl, pid } for a genuine token, otherwise null. */
export async function readToken(secret, token) {
  const parts = String(token || "").split(".");
  if (parts.length !== 5) return null;
  const [nonce, started, lvl, pid, sig] = parts;
  if ((await sign(secret, [nonce, started, lvl, pid].join("."))) !== sig) return null;
  return { nonce, started: +started, lvl: +lvl, pid };
}

/** Deterministic 32-bit seed for a run, derived from its nonce. The client can't choose or predict it. */
export async function seedFor(secret, nonce) {
  const k = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const d = new Uint8Array(await crypto.subtle.sign("HMAC", k, enc.encode("seed." + nonce)));
  return ((d[0] << 24) | (d[1] << 16) | (d[2] << 8) | d[3]) >>> 0;
}
