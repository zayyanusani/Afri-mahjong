// Weekly league (Cloudflare D1). Players sit in groups of up to 30 within a tier. When a week ends
// (Monday 00:00 UTC) the top 5 of each group move up a tier and the bottom 5 move down. Settling happens
// lazily the first time a player is seen in the new week, so no scheduled job is needed.
export const TIERS = ["Bronze", "Silver", "Gold", "Platinum", "Epic"];
export const GROUP = 30, PROMOTE = 5, DEMOTE = 5, MIN_FOR_DEMOTION = 8;

/** Weekly chest: more for promotion and for finishing on the podium. */
export function rewardFor(from, to, rank) {
  let coins = to > from ? 150 + to * 50 : to === from ? 80 : 40;
  coins += rank === 1 ? 200 : rank === 2 ? 120 : rank === 3 ? 80 : 0;
  const b = to > from ? { s: 1, h: 1, u: 1 } : rank <= 3 ? { s: 1, h: 0, u: 0 } : { s: 0, h: 0, u: 0 };
  return { coins, boosters: b };
}

export function weekKey(now = new Date()) {
  const t = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  t.setUTCDate(t.getUTCDate() - ((t.getUTCDay() + 6) % 7)); // back to Monday
  return t.toISOString().slice(0, 10);
}
export const weekEnds = (wk) => Date.parse(wk + "T00:00:00Z") + 7 * 86400e3;

/** Settles last week if needed, then makes sure the player has a seat in this week's group. */
export async function ensureMember(env, pid, name, now = new Date()) {
  const db = env.DB, wk = weekKey(now);
  const p = await db.prepare("SELECT tier, week FROM ptier WHERE pid = ?1").bind(pid).first();
  let tier = 0;
  if (!p) {
    await db.prepare("INSERT OR IGNORE INTO ptier (pid, tier, week) VALUES (?1, 0, ?2)").bind(pid, wk).run();
  } else {
    tier = p.tier;
    if (p.week < wk) {
      const prev = await db.prepare("SELECT tier, grp, score FROM members WHERE week = ?1 AND pid = ?2").bind(p.week, pid).first();
      if (prev) {
        const size = (await db.prepare("SELECT COUNT(*) AS n FROM members WHERE week = ?1 AND tier = ?2 AND grp = ?3").bind(p.week, prev.tier, prev.grp).first()).n;
        const rank = (await db.prepare("SELECT COUNT(*) + 1 AS r FROM members WHERE week = ?1 AND tier = ?2 AND grp = ?3 AND score > ?4").bind(p.week, prev.tier, prev.grp, prev.score).first()).r;
        let to = tier;
        if (prev.score > 0 && rank <= PROMOTE && tier < TIERS.length - 1) to = tier + 1;
        else if (size >= MIN_FOR_DEMOTION && rank > size - DEMOTE && tier > 0) to = tier - 1;
        if (prev.score === 0 && to === tier) { // joined but never scored: no result to show
          await db.prepare("UPDATE ptier SET week = ?2 WHERE pid = ?1").bind(pid, wk).run();
        } else {
          await db.prepare("UPDATE ptier SET tier = ?2, week = ?3, prev_week = ?4, prev_from = ?5, prev_to = ?6, prev_rank = ?7, prev_claimed = 0 WHERE pid = ?1").bind(pid, to, wk, p.week, tier, to, rank).run();
        }
        tier = to;
      } else { // did not play last week: no change, no result to show
        await db.prepare("UPDATE ptier SET week = ?2 WHERE pid = ?1").bind(pid, wk).run();
      }
    }
  }
  let m = await db.prepare("SELECT tier, grp FROM members WHERE week = ?1 AND pid = ?2").bind(wk, pid).first();
  if (!m) {
    const g = await db.prepare("SELECT grp, COUNT(*) AS n FROM members WHERE week = ?1 AND tier = ?2 GROUP BY grp ORDER BY grp DESC LIMIT 1").bind(wk, tier).first();
    const grp = !g ? 0 : g.n >= GROUP ? g.grp + 1 : g.grp;
    await db.prepare("INSERT OR IGNORE INTO members (week, pid, tier, grp, name, score) VALUES (?1, ?2, ?3, ?4, ?5, 0)").bind(wk, pid, tier, grp, name || "Player").run();
    m = await db.prepare("SELECT tier, grp FROM members WHERE week = ?1 AND pid = ?2").bind(wk, pid).first();
  }
  return { week: wk, tier: m.tier, grp: m.grp };
}

export async function addPoints(env, pid, name, points, now = new Date()) {
  const m = await ensureMember(env, pid, name, now);
  await env.DB.prepare("UPDATE members SET score = score + ?3, name = ?4 WHERE week = ?1 AND pid = ?2").bind(m.week, pid, points, name || "Player").run();
  return m;
}

export async function standing(env, pid, name, now = new Date()) {
  const m = await ensureMember(env, pid, name, now);
  const rows = (await env.DB.prepare("SELECT pid, name, score FROM members WHERE week = ?1 AND tier = ?2 AND grp = ?3 ORDER BY score DESC, name ASC LIMIT ?4").bind(m.week, m.tier, m.grp, GROUP + 10).all()).results;
  const p = await env.DB.prepare("SELECT prev_week, prev_from, prev_to, prev_rank, prev_claimed FROM ptier WHERE pid = ?1").bind(pid).first();
  return {
    week: m.week, endsAt: weekEnds(m.week), tier: m.tier, tierName: TIERS[m.tier], size: rows.length, promote: PROMOTE, demote: DEMOTE,
    rank: rows.findIndex((r) => r.pid === pid) + 1,
    rows: rows.map((r) => ({ name: r.name, score: r.score, me: r.pid === pid })),
    prev: p && p.prev_from != null ? { week: p.prev_week, from: p.prev_from, to: p.prev_to, rank: p.prev_rank, fromName: TIERS[p.prev_from], toName: TIERS[p.prev_to], claimed: p.prev_claimed !== 0, reward: rewardFor(p.prev_from, p.prev_to, p.prev_rank) } : null,
  };
}
