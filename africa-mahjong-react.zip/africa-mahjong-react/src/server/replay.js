// Replays a player's move log on the seeded board and returns the verified score. Throws if anything is illegal.
import { createRun, apply, isCleared, timeBonus, MIN_GAP_MS } from "../core.js";

const KINDS = new Set(["p", "u", "s", "x"]);
const MAX_ACTIONS = 3000;

export function verifyRun({ spec, seed, actions, timeUsed, elapsedMs }) {
  if (!Array.isArray(actions) || actions.length === 0 || actions.length > MAX_ACTIONS) throw new Error("bad move log");
  if (!(typeof timeUsed === "number" && timeUsed >= 0 && timeUsed <= elapsedMs / 1000 + 3)) throw new Error("bad time used");
  if (!(elapsedMs <= 6 * 3600e3)) throw new Error("run too long");

  let st = createRun(spec, seed), extras = 0, prevT = null;
  for (const a of actions) {
    if (!a || !KINDS.has(a.k) || !Number.isInteger(a.t) || a.t < 0) throw new Error("bad action");
    if (prevT !== null && a.t - prevT < MIN_GAP_MS) throw new Error("moves too fast");
    if (a.t > elapsedMs + 3000) throw new Error("action after the run ended");
    prevT = a.t;
    if (isCleared(st)) throw new Error("moves after the board was cleared");
    if (a.k === "x") {
      if (!spec.timeSec) throw new Error("no extra time on this level");
      extras++;
      continue;
    }
    st = apply(st, a);
  }
  if (!isCleared(st)) throw new Error("board not cleared");
  if (spec.timeSec && timeUsed > spec.timeSec + extras * 30 + 1) throw new Error("time used is longer than the clock");
  const bonus = timeBonus(spec, timeUsed, extras);
  return { matchScore: st.score, bonus, score: st.score + bonus, extras };
}
