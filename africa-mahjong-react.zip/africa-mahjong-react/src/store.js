import { useEffect, useState } from "react";

const KEY = "am2";
export const today = () => new Date().toDateString();
const DEF = { lvl: 1, coins: 0, b: { s: 3, h: 3, u: 3 }, wins: 0, day: "", cl: 0, mt: 0, cc: [0, 0, 0], seen: 0, mute: 0, theme: "animals", own: [], streak: 0, last: "", hs: 0, pid: "", name: "", sm: [], tier: 0, lw: "", chest: false };

function load() {
  const s = structuredClone(DEF);
  try { Object.assign(s, JSON.parse(localStorage.getItem(KEY) || "{}")); } catch { /* ignore */ }
  if (!s.pid) { s.pid = crypto.randomUUID(); s.name = "Player" + (1000 + ((Math.random() * 9000) | 0)); }
  if (s.day !== today()) { s.day = today(); s.cl = 0; s.mt = 0; s.cc = [0, 0, 0]; }
  return s;
}

/** Persistent game state. `up(fn)` mutates a clone of the state inside fn. */
export function useSave() {
  const [S, set] = useState(load);
  useEffect(() => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch { /* ignore */ } }, [S]);
  const up = (fn) => set((p) => { const n = structuredClone(p); fn(n); return n; });
  return [S, up];
}
