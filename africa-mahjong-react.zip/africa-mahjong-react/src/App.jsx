import { useCallback, useEffect, useRef, useState } from "react";
import Home from "./Home.jsx";
import Game from "./Game.jsx";
import ModalHost from "./Modals.jsx";
import { useSave, today } from "./store.js";
import { setMuted } from "./engine.js";
import { REG } from "./data.js";

export default function App() {
  const [S, up] = useSave();
  const [screen, setScreen] = useState("home");
  const [run, setRun] = useState(0);
  const [modal, setModal] = useState(null);
  const [msg, setMsg] = useState("");
  const [installEv, setInstallEv] = useState(null);
  const timer = useRef();

  setMuted(S.mute); // keep the audio engine in sync before children render

  const toast = useCallback((m) => {
    setMsg(m); clearTimeout(timer.current);
    timer.current = setTimeout(() => setMsg(""), 1300);
  }, []);
  const open = (m) => setModal(m);
  const close = () => setModal(null);
  const ri = (S.lvl - 1) % REG.length;
  const special = S.lvl % 5 === 0;

  useEffect(() => { if (S.last !== today() && S.seen) open({ kind: "daily", noclose: 1 }); }, []);
  useEffect(() => {
    const f = (e) => { e.preventDefault(); setInstallEv(e); };
    addEventListener("beforeinstallprompt", f);
    return () => removeEventListener("beforeinstallprompt", f);
  }, []);

  const install = () => { installEv?.prompt(); setInstallEv(null); };
  const standalone = matchMedia("(display-mode: standalone)").matches;
  const ctx = { paused: !!modal, S, up, toast, open, close, ri, special, go: setScreen, restart: () => setRun((r) => r + 1), install: installEv ? install : null, standalone };
  const play = () => {
    if (!S.seen) { up((s) => { s.seen = 1; }); open({ kind: "league" }); } else setScreen("game");
  };

  return (
    <>
      {screen === "home" ? <Home {...ctx} play={play} /> : <Game key={`${S.lvl}-${run}`} {...ctx} />}
      {modal && <ModalHost m={modal} ctx={ctx} />}
      <div id="toast" className={msg ? "on" : ""}>{msg}</div>
    </>
  );
}
