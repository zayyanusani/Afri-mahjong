// Deterministic game rules, shared by the browser and the Cloudflare league server.
// The server replays a player's move log with this module and recomputes the score itself,
// so scores sent by the device are never trusted. Keep this file free of imports and browser APIs.

export const WAVE_AT = [0.25, 0.5, 0.7];
export const COMBO_MS = 5000;
export const MIN_GAP_MS = 120;

/** Seeded PRNG (mulberry32). The generator state lives in r.s, so a run replays exactly from its seed. */
export function rnd(r) {
  r.s = (r.s + 0x6d2b79f5) >>> 0;
  let t = r.s;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

export const visibleOf = (T) => T.filter((t) => !t.gone && !t.hid);
export const isCleared = (st) => st.T.every((t) => t.gone);

/** Free = nothing covers it, and it isn't boxed in on both sides. `set` is the list of tiles that count. */
export function isFree(t, set) {
  let left = false, right = false;
  for (const o of set) {
    if (o === t) continue;
    if (o.z === t.z + 1 && Math.abs(o.x - t.x) < 2 && Math.abs(o.y - t.y) < 2) return false;
    if (o.z === t.z && Math.abs(o.y - t.y) < 2) {
      const d = o.x - t.x;
      if (d < 0 && d >= -2) left = true;
      if (d > 0 && d <= 2) right = true;
    }
  }
  return !(left && right);
}

export function canPick(st, i) {
  const t = st.T[i];
  if (!t || t.gone || t.hid || t.seal > st.mc) return false;
  return isFree(t, visibleOf(st.T));
}

/** Two playable tiles with the same symbol, as tile indices, or null. */
export function findPair(st) {
  const vis = visibleOf(st.T);
  const free = vis.filter((t) => t.seal <= st.mc && isFree(t, vis));
  for (let a = 0; a < free.length; a++)
    for (let b = a + 1; b < free.length; b++)
      if (free[a].s === free[b].s) return [free[a].i, free[b].i];
  return null;
}

/** Gives every tile a symbol so the board can be cleared in some order. Retries until it works. */
export function assign(tiles, pairs, r) {
  for (let attempt = 0; attempt < 300; attempt++) {
    const rest = tiles.slice(), ps = pairs.slice();
    for (let i = ps.length - 1; i > 0; i--) {
      const j = Math.floor(rnd(r) * (i + 1));
      [ps[i], ps[j]] = [ps[j], ps[i]];
    }
    let ok = true;
    for (const s of ps) {
      const f = rest.filter((t) => isFree(t, rest));
      if (f.length < 2) { ok = false; break; }
      const ai = Math.floor(rnd(r) * f.length), a = f[ai];
      f.splice(ai, 1);
      const b = f[Math.floor(rnd(r) * f.length)];
      a.s = b.s = s;
      rest.splice(rest.indexOf(a), 1);
      rest.splice(rest.indexOf(b), 1);
    }
    if (ok) return true;
  }
  return false;
}

/** Builds a level from its spec and a seed. The same seed and spec always give the same starting board. */
export function createRun(spec, seed) {
  const r = { s: seed >>> 0 };
  const T = spec.layout.map((p, i) => ({ x: p.x, y: p.y, z: p.z, i, s: -1, gone: false, hid: false, w: 0, seal: 0 }));
  const pairs = [16, 17];
  for (let i = 0; i < T.length / 2 - 2; i++) pairs.push(i % spec.K);
  if (!assign(T, pairs, r)) throw new Error("board generation failed");
  if (spec.seals) {
    const keys = T.map(() => rnd(r));
    const order = T.map((_, i) => i).sort((a, b) => keys[a] - keys[b]);
    const cap = Math.max(3, Math.floor((T.length / 2) * 0.6));
    order.slice(0, spec.seals).forEach((ti, k) => { T[ti].seal = Math.min(3 + k * spec.sealStep, cap); });
  }
  if (spec.waves) {
    const keys = T.map(() => rnd(r));
    const order = T.map((_, i) => i).sort((a, b) => (T[b].z - T[a].z) || (keys[a] - keys[b]));
    const n = Math.ceil(T.length * 0.3);
    order.slice(0, n).forEach((ti, k) => { T[ti].hid = true; T[ti].w = spec.waves - Math.floor((k * spec.waves) / n); });
  }
  const st = { spec, T, mc: 0, wave: 0, score: 0, combo: 0, last: -1e9, sel: null, hist: [], rng: r, sh: 0, ck: [], rw: 0 };
  settle(st);
  return st;
}

const cloneT = (T) => T.map((t) => ({ ...t }));
const snap = (st) => ({ T: cloneT(st.T), mc: st.mc, wave: st.wave, score: st.score, combo: st.combo, last: st.last, sel: st.sel, rng: { s: st.rng.s }, sh: st.sh });
const restore = (sn) => ({ T: cloneT(sn.T), mc: sn.mc, wave: sn.wave, score: sn.score, combo: sn.combo, last: sn.last, sel: null, rng: { s: sn.rng.s }, sh: sn.sh });

/**
 * Applies one player action and returns the new state (the input is never mutated).
 * Actions: {k:'p', i, t} tap a tile, {k:'u', t} undo, {k:'s', t} reshuffle, {k:'x', t} buy extra time.
 * Throws on anything illegal, so the server can reject a bad move log.
 */
export function apply(prev, act) {
  if (!act || !Number.isFinite(act.t)) throw new Error("missing time");
  if (act.k === "u") {
    if (!prev.hist.length) throw new Error("nothing to undo");
    return { ...prev, ...restore(prev.hist[prev.hist.length - 1]), hist: prev.hist.slice(0, -1) };
  }
  const st = {
    ...prev, T: cloneT(prev.T), rng: { s: prev.rng.s }, hist: prev.hist.slice(),
    ck: findPair(prev) ? prev.ck.concat([snap(prev)]).slice(-40) : prev.ck.slice(),
  };
  if (act.k === "p") return pick(prev, st, act);
  if (act.k === "s") { if (!doShuffle(st)) throw new Error("reshuffle failed"); settle(st); return st; }
  if (act.k === "x") return st;
  throw new Error("unknown action");
}

function pick(prev, st, act) {
  const i = act.i;
  if (!Number.isInteger(i) || i < 0 || i >= st.T.length) throw new Error("bad tile");
  if (st.sel === i) { st.sel = null; return st; }
  if (!canPick(prev, i)) throw new Error("tile is not free");
  if (st.sel === null || !canPick(prev, st.sel)) { st.sel = i; return st; }
  const a = st.T[st.sel], b = st.T[i];
  if (a.s !== b.s) { st.sel = i; return st; }
  st.hist = prev.hist.concat([snap(prev)]);
  a.gone = b.gone = true;
  st.sel = null;
  st.combo = act.t - prev.last < COMBO_MS ? prev.combo + 1 : 1;
  st.last = act.t;
  st.score = prev.score + 10 + Math.min(st.combo - 1, 5) * 5;
  st.mc = prev.mc + 1;
  afterMatch(st);
  if (a.s === 17) doShuffle(st); // rain tile reshuffles the rest of the board
  settle(st);
  return st;
}

function releaseWave(st) {
  const w = ++st.wave;
  st.T.forEach((t) => { if (t.hid && t.w <= w) t.hid = false; });
}

function afterMatch(st) {
  while (st.wave < st.spec.waves && st.mc >= Math.ceil(st.spec.pairs * WAVE_AT[st.wave])) releaseWave(st);
}

function doShuffle(st) {
  const rem = st.T.filter((t) => !t.gone);
  if (!rem.length) return false;
  const ss = rem.map((t) => t.s).sort((a, b) => a - b), ps = [];
  for (let i = 0; i < ss.length; i += 2) ps.push(ss[i]);
  if (assign(rem, ps, st.rng)) { st.sel = null; st.hist = []; st.sh++; return true; }

  // No fully solvable arrangement exists for these tile positions. Fall back to a random arrangement
  // that still has a playable pair, so the player is never left with no move at all.
  const bag = [];
  ps.forEach((s) => bag.push(s, s));
  for (let i = bag.length - 1; i > 0; i--) {
    const j = Math.floor(rnd(st.rng) * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  rem.forEach((t, k) => { t.s = bag[k]; });
  const vis = rem.filter((t) => !t.hid), free = vis.filter((t) => isFree(t, vis));
  if (free.length >= 2 && free[0].s !== free[1].s) {
    const f0 = free[0], f1 = free[1];
    const q = rem.find((t) => t !== f0 && t.s === f0.s);
    const tmp = q.s; q.s = f1.s; f1.s = tmp; // swap so the two free tiles match (counts stay even)
  }
  st.sel = null; st.hist = []; st.sh++;
  return true;
}

/** Number of visible tiles that are free to move (ignores symbols). */
function freeVisible(st) {
  const vis = visibleOf(st.T);
  return vis.filter((t) => isFree(t, vis)).length;
}

/** When stuck: release the next wave, break seals, reshuffle if that can create a pair, else rewind. */
function settle(st) {
  for (let guard = 0; guard < 80; guard++) {
    if (isCleared(st) || findPair(st)) return;
    if (st.T.some((t) => t.hid)) { releaseWave(st); continue; }
    if (st.T.some((t) => !t.gone && t.seal > st.mc)) { st.mc = 99; continue; }
    if (freeVisible(st) >= 2) { if (!doShuffle(st)) return; continue; }
    if (!rewind(st)) return; // dead end with no checkpoint left
  }
}

/** Dead end: go back to the most recent playable position. Deterministic, so the server replays it too. */
const MAX_REWINDS = 10; // per run, so a repeated bad line can't loop forever; then the dead-end popup takes over
function rewind(st) {
  if (!st.ck.length || (st.rw || 0) >= MAX_REWINDS) return false;
  // each rewind in a run goes one checkpoint further back, so a repeated bad line can't land on the same dead end
  const back = Math.min(st.ck.length, 1 + (st.rw || 0));
  const sn = st.ck[st.ck.length - back];
  Object.assign(st, restore(sn));
  st.ck = st.ck.slice(0, -back);
  st.hist = [];
  st.rw = (st.rw || 0) + 1;
  return true;
}

/** Seconds of the rush clock left at the end, capped at the rush length. */
export function timeBonus(spec, timeUsed, extras) {
  if (!spec.timeSec) return 0;
  return Math.round(Math.min(spec.timeSec, Math.max(0, spec.timeSec + extras * 30 - timeUsed)));
}
